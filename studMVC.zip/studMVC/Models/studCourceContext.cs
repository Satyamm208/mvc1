﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace studMVC.Models
{
    public partial class studCourceContext : DbContext
    {
        public studCourceContext()
        {
        }

        public studCourceContext(DbContextOptions<studCourceContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Course> Course { get; set; }
        public virtual DbSet<Stud> Stud { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-5QKDOVN;Initial Catalog=studCource;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Course>(entity =>
            {
                entity.ToTable("course");

                entity.Property(e => e.CourseId).HasColumnName("courseId");

                entity.Property(e => e.CourseName)
                    .HasColumnName("courseName")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Stud>(entity =>
            {
                entity.ToTable("stud");

                entity.Property(e => e.StudId).HasColumnName("studId");

                entity.Property(e => e.CourseId).HasColumnName("courseId");

                entity.Property(e => e.StudAge).HasColumnName("studAge");

                entity.Property(e => e.StudName)
                    .HasColumnName("studName")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.Stud)
                    .HasForeignKey(d => d.CourseId)
                    .HasConstraintName("FK_stud_stud");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
